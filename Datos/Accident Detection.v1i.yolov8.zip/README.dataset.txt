# Accident Detection > 2024-07-09 3:18am
https://universe.roboflow.com/accidentdetection-swaec/accident-detection-ava9z

Provided by a Roboflow user
License: CC BY 4.0

